package com.cg.domain;

public class MediaPath {
	private String mediaPath;

	public String getMediaPath() {
		return mediaPath;
	}

	public void setMediaPath(String mediaPath) {
		this.mediaPath = mediaPath;
	}

	public MediaPath(String mediaPath) {
		super();
		this.mediaPath = mediaPath;
	}
	

}
