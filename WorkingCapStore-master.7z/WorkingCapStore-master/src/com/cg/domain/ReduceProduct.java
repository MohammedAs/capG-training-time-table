package com.cg.domain;

public class ReduceProduct {
private String product_id;
private long reduceQuantity;
public String getProduct_id() {
	return product_id;
}
public void setProduct_id(String product_id) {
	this.product_id = product_id;
}
public long getReduceQuantity() {
	return reduceQuantity;
}
public void setReduceQuantity(long l) {
	this.reduceQuantity = l;
}
}
