@javax.xml.bind.annotation.XmlSchema(namespace = "http://webservice.cg.com/")
package com.cg.bankservice;
