/*$(document).ready(function(){
     $.ajax({
         type: "GET",
         url: "getSuggestions",
         dataType: 'jsonp',
         jsonp: 'callback',
         jsonpCallback: 'jsonpCallback',
         error: function(jqXHR, textStatus, errorThrown){
               $("#ajaxResponse2").html(jqXHR.responseText);
         },
     });         
   
  });
    function jsonpCallback(data) {
        console.log("callback",data);
     }
*/